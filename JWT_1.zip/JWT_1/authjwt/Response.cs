﻿namespace authjwt
{
    public class Response
    {
        public Response(string status,string message)
        {
            this.Status = status;
            this.Message = message;
        }
        public Response(string status, string message,object result=null)
        {
            this.Status = status;
            this.Message = message;
            this.Result = result;
        }

        public string Status { get; set; }
        public string Message { get; set; }
        public object? Result { get; set; }
    }
}
