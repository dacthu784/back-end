﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace authjwt
{
    public class JwtService
    {
        private readonly IConfiguration _configuration;
        private readonly string _jwtAccessSecret;
        private readonly string _jwtRefreshSecret;
        private readonly string _audience;
        private readonly string _issuer;
            // đọc cấu hình
        public JwtService(IConfiguration configuration)
        {
            _configuration = configuration;
            _jwtAccessSecret = _configuration.GetSection("JWT:Access_Secret").Value;
            _jwtRefreshSecret = _configuration.GetSection("JWT:Refresh_Secret").Value;
            _audience = _configuration.GetSection("JWT:ValidAudience").Value;
            _issuer = _configuration.GetSection("JWT:ValidIssuer").Value;

        }
        public async Task<bool> ValidateRefreshTokenAsync(string refreshToken)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtRefreshSecret); // Use the secret key for refresh tokens
            try
            {
                SecurityToken validatedToken;
                        // xác thực refreshToken
                        tokenHandler.ValidateToken(refreshToken, new TokenValidationParameters
                {
                    //Xác nhận rằng issuer của token (nơi tạo ra token) phải trùng khớp với giá trị được chỉ định trong _issuer.
                    ValidateIssuer = true,
                    //Xác nhận rằng audience của token (đối tượng mà token được tạo cho) phải trùng khớp với giá trị được chỉ định trong _audience. 
                    ValidateAudience = true,
                    //Định rõ issuer (nơi tạo ra token) hợp lệ. Trong trường hợp này, giá trị của _issuer được sử dụng để so sánh với issuer trong token.
                    ValidIssuer = _issuer,
                    // Định rõ audience (đối tượng mà token được tạo cho) hợp lệ.
                    ValidAudience = _audience,
                    //Xác nhận rằng token phải còn hiệu lực (chưa hết hạn) để được xác thực.
                    ValidateLifetime = true,
                    //Sử dụng key  để xác minh chữ ký của token
                    IssuerSigningKey = new SymmetricSecurityKey(key)
                }, out validatedToken);
                return true;
                // Optionally, check if the refresh token is valid in your database
                //var refreshTokenExistsInDatabase = await CheckIfRefreshTokenExistsAsync(refreshToken);

                //if (refreshTokenExistsInDatabase)
                //{
                //    return true;
                //}
            }
            catch (Exception)
            {
                // Token validation failed
            }

            return false;
        }

        public async Task<string> RefreshTokenAsync(JwtPayloads payload)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtRefreshSecret);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Audience = _audience,
                Issuer = _issuer,
                Subject = new ClaimsIdentity(new[]
                {
            new Claim(ClaimTypes.NameIdentifier, payload.Id.ToString()),
                new Claim(ClaimTypes.Name, payload.UserName.ToString()),
                new Claim(ClaimTypes.Role, payload.RoleId.ToString()),
            // Add any other claims you want to include in the refreshed token
        }),
                Expires = DateTime.UtcNow.AddDays(7), // Extend the expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
            };

            var refreshedToken = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(refreshedToken).ToString();
        }

        public async Task<string> GenerateJwtTokenAsync(JwtPayloads payload)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtAccessSecret);


            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Audience = _audience,
                Issuer = _issuer,
                Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.NameIdentifier, payload?.Id.ToString()),
                new Claim(ClaimTypes.Name, payload?.UserName.ToString()),
                new Claim(ClaimTypes.Role, payload?.RoleId.ToString()),

                // Các claim khác bạn muốn thêm vào mã JWT
            }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token).ToString();

        }
        public async Task<JwtPayloads> DecodeJwtToken(string token)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtAccessSecret);

            try
            {
                SecurityToken validatedToken;
                var principal = tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = _issuer,
                    ValidAudience = _audience,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                }, out validatedToken);
                // Retrieve the token's expiration time
                var expirationTime = validatedToken.ValidTo;

                // Calculate the remaining time until token expiration
                var timeUntilExpiration = expirationTime - DateTime.UtcNow;
                // Token hợp lệ, trích xuất thông tin
                var userId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var username = principal.FindFirst(ClaimTypes.Name)?.Value;
                var roleId = principal.FindFirst(ClaimTypes.Role)?.Value;


                // Xây dựng đối tượng chứa thông tin cần trả về
                return new JwtPayloads()
                {
                    Id = userId,
                    UserName = username,
                    RoleId = roleId,

                };


            }
            catch (Exception ex)
            {
                // Xử lý lỗi và trả về một response lỗi

            }
            return null;
        }

    }
}
