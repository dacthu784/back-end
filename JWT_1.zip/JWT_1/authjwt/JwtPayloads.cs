﻿namespace authjwt
{
    public class JwtPayloads
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string RoleId { get; set; }
    }
}
