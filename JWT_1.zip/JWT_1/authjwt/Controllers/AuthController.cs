﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Net;

namespace authjwt.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public class RegisterUserDTO
        {
            public string UserName { get; set; }
            public string Password { get; set; }
        }

        private readonly JwtService _jwtService;
        public AuthController(JwtService jwtService)
        {

            this._jwtService = jwtService;
        }
            //login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] RegisterUserDTO dto)
        {
                  var payload = new JwtPayloads()
                  {
                        Id = Guid.NewGuid().ToString(),
                        UserName = dto.UserName,
                        RoleId = Guid.NewGuid().ToString(),
                  };
                  //var payload = new JwtPayloads
                  //{
                  //      Id = "12345",
                  //      UserName = "datchudinh784",
                  //      RoleId = "admin"
                  //};
                  // tạo mã JWT dựa trên thông tin người dùng
                  var accessToken = await _jwtService.GenerateJwtTokenAsync(payload);
            var refreshToken = await _jwtService.RefreshTokenAsync(payload);
            return Ok(new { accessToken, refreshToken });
        }
        [Authorize]
        [HttpPost("refreshToken")]
        public async Task<ActionResult<Response>> RefreshToken([FromBody] RefreshTokenDTO dto)
        {
            try
            {

                string accessToken = null;
                string refreshToken = null;
                string authorizationHeader = Request.Headers["Authorization"];
                if (authorizationHeader == null || !authorizationHeader.StartsWith("Bearer "))
                {
                    return Unauthorized();
                }
                var check = await _jwtService.ValidateRefreshTokenAsync(dto.RefreshToken);
                if (!check) return BadRequest(new Response(HttpStatusCode.BadRequest.ToString(), "RefreshToken is valid"));
                string idToken = authorizationHeader.Substring("Bearer ".Length);

                var decodeToken = await _jwtService.DecodeJwtToken(idToken);

                if (decodeToken != null)
                {
                    accessToken = await _jwtService.GenerateJwtTokenAsync(decodeToken);
                    refreshToken = await _jwtService.RefreshTokenAsync(decodeToken);
                }


                return Ok(new
                {
                    accessToken,
                    refreshToken,
                    decodeToken
                });
            }
                  // xử lý nếu có bất kỳ lỗi nào xảy ra trong quá trình xác thực token JW
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }

        }
        public class AccessTokenDTO
        {
            public string AccessToken { get; set; }
        }
        public class RefreshTokenDTO
        {
            public string RefreshToken { get; set; }
        }
        [HttpPost("decodeToken")]
        public async Task<IActionResult> DecodeToken([FromBody] AccessTokenDTO token)
        {
            try
            {
                var decodeToken = await _jwtService.DecodeJwtToken(token.AccessToken);

                return Ok(new
                {
                    decodeToken
                });
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

    }
}
